
# All states in Micro

# For ipmi conf record
# Get from ironic or maas
IPMI_CONF_RAW = 'raw'
# Updated
IPMI_CONF_CONFED = 'confed'
# Deleted
IPMI_CONF_DEL = 'del'
#Config success
IPMI_CONF_SUCCESS = 'success'